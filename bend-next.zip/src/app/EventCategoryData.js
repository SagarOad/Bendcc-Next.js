const EventCategoryData = [
    { value: 1, label: "Wedding" },
    { value: 2, label: "Birthday" },
    { value: 3, label: "Party" },
    { value: 3, label: "Funeral" },
  ];
  
  export default EventCategoryData;