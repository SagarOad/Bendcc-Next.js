import React from 'react'
import Home from './Pages/Home'
// import EventPage from './Event/page'

function page() {
  return (
    <>
    {/* <EventPage /> */}
     <Home />
    </>
  )
}

export default page