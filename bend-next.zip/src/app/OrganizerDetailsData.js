const OrganizerDetailsData = [
    { value: 1, label: "Create or Find an Organizer" },
    { value: 2, label: "Aaron Hofferber" },
    { value: 3, label: "Carl Nokell" },
    { value: 4, label: "Chris Sanford" },
    { value: 5, label: "Eric Fannin" },
    { value: 6, label: "Miguel Rangel" },
    { value: 7, label: "New Person" },
  ];
  
  export default OrganizerDetailsData;