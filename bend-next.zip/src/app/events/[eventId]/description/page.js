const page = ( params ) => {
  return (
    <div>
        {params.event_description}
    </div>
  )
}

export default page