const VenueDetailData = [
    { value: 1, label: "Bend Car & Coffe" },
    { value: 2, label: "Bend Datsun" },
    { value: 3, label: "Bend Walmart" },
    { value: 4, label: "Fireman Pont" },
    { value: 5, label: "General Duffy's Waterhole" },
    { value: 6, label: "New spot" },
    { value: 7, label: "NW WHEEL AND FIRE" },
    { value: 8, label: "Royal Tint N Dip" },
  ];
  
  export default VenueDetailData;