import React from "react";

const Footer = () => {
  return (
    <div>
      <div className="footer">
        <div className="container">
          <p>Designed and developed by Fameitech ©. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
};

export default Footer;
